package com.appleyk.service;

public interface QuestionService {
	String answer(String question) throws Exception;
}

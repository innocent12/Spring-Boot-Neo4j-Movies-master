package com.appleyk.repository;

public interface InsectRepository {
}
